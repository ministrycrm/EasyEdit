<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Documentation:
Create Snippets and Chunks 

Create the following TVs:
layoutmode (text)
zone2 (richtext)
zone3 (richtext)
zone4 (richtext)
zone5 (richtext)
zone6 (richtext)

Included is a modified version of the Clarity Template with the appropriate EasyEdit tags.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a25ceca60f740908af9fb3a03bbc0b07',
      'native_key' => 'easyedit',
      'filename' => 'modNamespace/92ef0ed4ee109fac01dc5a77070d3c43.vehicle',
      'namespace' => 'easyedit',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f5641bb0ab2c752815a11ff111b66cf6',
      'native_key' => 1,
      'filename' => 'modCategory/25d36cc9997a612644ff8f3ad7e317fa.vehicle',
      'namespace' => 'easyedit',
    ),
  ),
);